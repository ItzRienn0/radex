settings = {
    'token': 'OTE5OTI1OTE4MDI0MjMyOTcw.Ybc5xg.b91wmGnnIhc2dycFVszR9KLu694',
    'prefix': '='

}

database = {
    'host': "195.161.62.153",
    'port': 3306,
    'user': "047527046_radex",
    'password': "6911286arm",
    'database': "j67301606_radexbot"
}